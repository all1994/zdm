package com.health.model;

public class CategoryModel {
    private int id; //category id
    private String title;
    private int drawable;

    public CategoryModel(int id, String title, int drawable){
        this.title = title;
        this.drawable = drawable;
        this.id = id;
    }

    public String getTitle(){
        return title;
    }

    public int getDrawable()
    {
        return drawable;
    }

    public int getCategoryId()
    {
        return id;
    }
}
