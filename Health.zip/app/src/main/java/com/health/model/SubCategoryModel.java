package com.health.model;

public class SubCategoryModel {

    private int id; //subcategory id
    private String title;
    private String drawable;
    private int categoryId;

    public SubCategoryModel(int id, String title, String drawable, int categoryId){
        this.id = id;
        this.title = title;
        this.drawable = drawable;
        this.categoryId = categoryId;
    }

    public String getTitle(){
        return title;
    }

    public String getDrawable()
    {
        return drawable;
    }

    public int getCategoryId(){
        return categoryId;
    }

    public int getSubCategoryId(){
        return id;
    }
}
