package com.health.model;

public class DrugTypeModel {

    private int id; //drug id
    private String title;
    private String drawable;
    private int subCategoryId;

    public DrugTypeModel(int id, String title, String drawable, int subCategoryId){
        this.id = id;
        this.title = title;
        this.drawable = drawable;
        this.subCategoryId = subCategoryId;
    }

    public String getTitle(){
        return title;
    }

    public String getDrawable()
    {
        return drawable;
    }

    public int getSubCategoryId()
    {
        return subCategoryId;
    }

    public int getDrugTypeId()
    {
        return id;
    }
}
