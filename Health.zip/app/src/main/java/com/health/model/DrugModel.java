package com.health.model;

public class DrugModel {

    private int id; //drug id
    private String title;
    private String price;
    private int amount;
    private int drugTypeId;

    public DrugModel(int id, String title, String price, int amount, int drugTypeId){
        this.id = id;
        this.title = title;
        this.price = price;
        this.amount = amount;
        this.drugTypeId = drugTypeId;
    }

    public String getTitle(){
        return title;
    }

    public String getPrice() {
        return price;
    }

    public int getAmount() {
        return amount;
    }

    public int getDrugTypeId() {
        return drugTypeId;
    }
}
