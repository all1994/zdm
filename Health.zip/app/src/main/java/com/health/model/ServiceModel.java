package com.health.model;

public class ServiceModel {

    private String title;
    private int color;
    private int drawable;

    public ServiceModel(String title, int color, int drawable){
        this.title = title;
        this.color = color;
        this.drawable = drawable;
    }

    public String getTitle(){
        return title;
    }

    public int getColor()
    {
        return color;
    }

    public int getDrawable()
    {
        return drawable;
    }
}
