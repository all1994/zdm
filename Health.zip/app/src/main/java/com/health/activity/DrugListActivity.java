package com.health.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.health.R;
import com.health.adapter.recyclerview.DrugAdapter;
import com.health.model.DrugModel;

import java.util.ArrayList;

public class DrugListActivity extends AppCompatActivity {

    private RecyclerView drugList;
    private GridLayoutManager mLayoutManager;
    private ArrayList<DrugModel> drugModels;
    DrugAdapter drugAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drug_list);
        drugList = findViewById(R.id.drugList);
        drugModels = new ArrayList<>();
        mLayoutManager =  new GridLayoutManager(this, 2);
        drugModels.add(new DrugModel(0, "Drug 1", "1293", 1, 1));
        drugModels.add(new DrugModel(1, "Drug 2", "293", 12, 1));
        drugModels.add(new DrugModel(2, "Drug 3", "19", 11, 1));
        drugModels.add(new DrugModel(3, "Drug 4", "123", 156, 1));
        drugModels.add(new DrugModel(4, "Drug 5", "93", 13, 1));
        drugModels.add(new DrugModel(5, "Drug 6", "1777", 17, 1));
        drugAdapter = new DrugAdapter(drugModels, this);
        drugList.setLayoutManager(mLayoutManager);
        drugList.setAdapter(drugAdapter);
    }
}
