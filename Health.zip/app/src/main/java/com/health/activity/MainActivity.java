package com.health.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.navigation.NavigationView;
import com.health.R;
import com.health.adapter.viewpager.MainPagerAdapter;

import me.ibrahimsn.lib.NiceBottomBar;
import me.ibrahimsn.lib.OnItemSelectedListener;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private NiceBottomBar bottomBar;
    private ViewPager viewPager;
    private MainPagerAdapter pagerAdapter;
    private ImageView menu;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomBar = findViewById(R.id.bottomBar);
        viewPager = findViewById(R.id.pager);
        menu = findViewById(R.id.menu);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        initTabViewPager();
        menu.setOnClickListener(this);
    }

    private void initTabViewPager() {
        pagerAdapter = new MainPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        bottomBar.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelect(int pos) {
                viewPager.setCurrentItem(pos);
            }
        });
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                bottomBar.setActiveItem(position);
            }

            @Override
            public void onPageSelected(int position) {
                bottomBar.setActiveItem(position);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.menu:
                drawerLayout.openDrawer(Gravity.LEFT);
                break;
        }
    }
}
