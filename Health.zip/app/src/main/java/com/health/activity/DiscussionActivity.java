package com.health.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.health.R;

public class DiscussionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discussion);
    }
}
