package com.health.util;

public class Constants {
    public static String categoryData="[{'id':0, 'title':'All'}," +
            "{'id':1, 'title':'Medicine'},{" +
            "'id':2, 'title':'Tool'}," +
            "{'id':3, 'title':'Health'}," +
            "{'id':4, 'title':'Cook'}," +
            "{'id':5, 'title':'Children'}," +
            "{'id':6, 'title':'Life'}]";
    public static String subCategoryData="[{'id':0, 'title':'man health', 'drawable':'img_qr', 'categoryId': 1}," +
            "{'id':1, 'title':'man health', 'drawable':'img_qr', 'categoryId': 1}," +
            "{'id':2, 'title':'women health', 'drawable':'img_qr', 'categoryId': 1}," +
            "{'id':3, 'title':'bone health', 'drawable':'img_qr', 'categoryId': 1}," +
            "{'id':4, 'title':'brain health', 'drawable':'img_qr', 'categoryId': 2}," +
            "{'id':5, 'title':'drink health', 'drawable':'img_qr', 'categoryId': 2}," +
            "{'id':6, 'title':'mouth health', 'drawable':'img_qr', 'categoryId': 3}]";
    public static String drugTypeData="[{'id':0, 'title':'drug type 1', 'drawable':'ic_home', 'subCategoryId': 0}," +
            "{'id':1, 'title':'drug type 2', 'drawable':'ic_home', 'subCategoryId': 0}," +
            "{'id':2, 'title':'drug type 3', 'drawable':'ic_home', 'subCategoryId': 0}," +
            "{'id':3, 'title':'drug type 4', 'drawable':'ic_home', 'subCategoryId': 0}," +
            "{'id':4, 'title':'drug type 5', 'drawable':'ic_home', 'subCategoryId': 1}," +
            "{'id':5, 'title':'drug type 6', 'drawable':'ic_home', 'subCategoryId': 1}," +
            "{'id':6, 'title':'drug type 7', 'drawable':'ic_home', 'subCategoryId': 1}," +
            "{'id':7, 'title':'drug type 8', 'drawable':'ic_home', 'subCategoryId': 2}," +
            "{'id':8, 'title':'drug type 9', 'drawable':'ic_home', 'subCategoryId': 3}," +
            "{'id':9, 'title':'drug type 10', 'drawable':'ic_home', 'subCategoryId': 4}," +
            "{'id':10, 'title':'drug type 11', 'drawable':'ic_home', 'subCategoryId': 5}," +
            "{'id':11, 'title':'drug type 12', 'drawable':'ic_home', 'subCategoryId': 5}," +
            "{'id':12, 'title':'drug type 13', 'drawable':'ic_home', 'subCategoryId': 6}," +
            "{'id':13, 'title':'drug type 14', 'drawable':'img_qr', 'subCategoryId': 6}]";
}
