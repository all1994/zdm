package com.health.interfaces;

public interface ServiceClickListener {
    void onServiceClick(int serviceId);
}