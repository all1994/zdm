package com.health.interfaces;

public interface CategoryClickListener {
    void onCategoryClick(int categoryId);
}