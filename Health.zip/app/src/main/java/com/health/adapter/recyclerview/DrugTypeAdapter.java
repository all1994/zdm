package com.health.adapter.recyclerview;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.activity.DrugListActivity;
import com.health.model.DrugTypeModel;

import java.util.ArrayList;

public class DrugTypeAdapter extends RecyclerView.Adapter<DrugTypeAdapter.ViewHolder> {

    private ArrayList<DrugTypeModel> models;
    private Context context;

    public DrugTypeAdapter(ArrayList<DrugTypeModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_drug_type, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.textView.setText(models.get(position).getTitle());
        viewHolder.drugContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DrugListActivity.class);
                intent.putExtra("drugType", models.get(position).getDrugTypeId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout drugContainer;
        TextView textView;
        ImageView imageView;

        public ViewHolder(View v) {
            super(v);
            drugContainer = (LinearLayout) v.findViewById(R.id.drugContainer);
            textView = (TextView) v.findViewById(R.id.title);
            imageView = (ImageView) v.findViewById(R.id.image);
        }
    }
}