package com.health.adapter.recyclerview;


import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.model.ServiceModel;

import java.util.ArrayList;

public class AccountInfoAdapter extends RecyclerView.Adapter<AccountInfoAdapter.ViewHolder> {

    private static final String TAG = "Cus tomAdapter";

    private ArrayList<ServiceModel> models;

    public AccountInfoAdapter(ArrayList<ServiceModel> models) {
        this.models = models;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textView;
        private final ImageView imageView;

        public ViewHolder(View v) {
            super(v);
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "Element " + getAdapterPosition() + " clicked.");
                }
            });
            textView = (TextView) v.findViewById(R.id.title);
            imageView = (ImageView) v.findViewById(R.id.image);
        }

        public TextView getTextView() {
            return textView;
        }

        public ImageView getImageView() {
            return imageView;
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_account_info, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.getTextView().setText(models.get(position).getTitle());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            viewHolder.getImageView().getBackground().setTint(models.get(position).getColor());
        }
        viewHolder.getImageView().setImageResource(models.get(position).getDrawable());
    }

    @Override
    public int getItemCount() {
        return models.size();
    }
}