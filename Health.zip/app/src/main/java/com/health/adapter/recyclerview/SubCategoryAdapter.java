package com.health.adapter.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.health.R;
import com.health.model.DrugTypeModel;
import com.health.model.SubCategoryModel;
import com.health.util.Constants;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;


public class SubCategoryAdapter extends RecyclerView.Adapter<SubCategoryAdapter.PersonViewHolder> {


    private List<SubCategoryModel> subList;
    private Context context;

    private static int currentPosition = 0;

    public SubCategoryAdapter(List<SubCategoryModel> subCategoryModels, Context context) {
        this.subList = subCategoryModels;
        this.context = context;
    }

    @Override
    public PersonViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sub_category, parent, false);
        return new PersonViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PersonViewHolder holder, final int position) {
        SubCategoryModel subCategoryModel = subList.get(position);
        holder.linearLayout.setVisibility(View.GONE);
        holder.titleView.setText(subCategoryModel.getTitle());
        final int ResourceID =
                context.getResources().getIdentifier(subCategoryModel.getDrawable(), "drawable",
                        context.getApplicationInfo().packageName);
        holder.imageView.setImageDrawable(context.getResources().getDrawable( ResourceID));

        if (currentPosition == position) {
//            Animation slideDown = AnimationUtils.loadAnimation(context, R.anim.slide_down);
            holder.linearLayout.setVisibility(View.VISIBLE);
//            holder.linearLayout.startAnimation(slideDown);
        }

        holder.titleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentPosition = position;
                notifyDataSetChanged();
            }
        });
        ArrayList<DrugTypeModel> drugModels = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(Constants.drugTypeData);
            for (int i = 0; i < jsonArray.length(); i++) {
                if (jsonArray.getJSONObject(i).getInt("subCategoryId")==subCategoryModel.getSubCategoryId())
                drugModels.add(new DrugTypeModel( jsonArray.getJSONObject(i).getInt("id"),
                        jsonArray.getJSONObject(i).getString("title"),
                        jsonArray.getJSONObject(i).getString("drawable"),
                        jsonArray.getJSONObject(i).getInt("subCategoryId")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        GridLayoutManager mLayoutManager =  new GridLayoutManager(context, 3);
        DrugTypeAdapter mAdapter = new DrugTypeAdapter(drugModels, context);
        holder.drugList.setLayoutManager(mLayoutManager);
        holder.drugList.setAdapter(mAdapter);
    }

    @Override
    public int getItemCount() {
        return subList.size();
    }

    class PersonViewHolder extends RecyclerView.ViewHolder {
        TextView  titleView;
        ImageView imageView;
        LinearLayout linearLayout;
        RecyclerView drugList;

        PersonViewHolder(View itemView) {
            super(itemView);
            titleView = (TextView) itemView.findViewById(R.id.titleView);
            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);
            drugList = (RecyclerView) itemView.findViewById(R.id.drugList);
        }
    }
}