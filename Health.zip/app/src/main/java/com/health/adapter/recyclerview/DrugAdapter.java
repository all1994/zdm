package com.health.adapter.recyclerview;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.activity.DrugListActivity;
import com.health.model.DrugModel;
import com.health.model.DrugTypeModel;

import java.util.ArrayList;

public class DrugAdapter extends RecyclerView.Adapter<DrugAdapter.ViewHolder> {

    private ArrayList<DrugModel> models;
    private Context context;

    public DrugAdapter(ArrayList<DrugModel> models, Context context) {
        this.models = models;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_drug, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.titleView.setText(models.get(position).getTitle());
        viewHolder.priceView.setText(models.get(position).getPrice());
        viewHolder.amountView.setText("Amount:"+ Integer.toString(models.get(position).getAmount()));
        viewHolder.drugContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout drugContainer;
        TextView titleView, priceView, amountView;
        ImageView imageView;

        public ViewHolder(View v) {
            super(v);
            drugContainer = (LinearLayout) v.findViewById(R.id.drugContainer);
            titleView = (TextView) v.findViewById(R.id.title);
            amountView = (TextView) v.findViewById(R.id.amount);
            priceView = (TextView) v.findViewById(R.id.price);
            imageView = (ImageView) v.findViewById(R.id.image);
        }
    }
}