package com.health.adapter.recyclerview;


import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.interfaces.CategoryClickListener;
import com.health.model.CategoryModel;
import com.health.model.ServiceModel;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    private static final String TAG = "CustomAdapter";

    private ArrayList<CategoryModel> models;
    private CategoryClickListener categoryClickListener;
    private Context context;

    private static int currentPosition = -1;

    public CategoryAdapter(ArrayList<CategoryModel> models, Context context, CategoryClickListener categoryClickListener) {
        this.models = models;
        this.categoryClickListener = categoryClickListener;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_category, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.textView.setText(models.get(position).getTitle());
//        viewHolder.getImageView().setImageResource(models.get(position).getDrawable());
        viewHolder.categoryContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryClickListener.onCategoryClick(models.get(position).getCategoryId());
                currentPosition = position;
                notifyDataSetChanged();
            }
        });
        viewHolder.categoryContainer.setBackgroundColor(context.getResources().getColor(R.color.colorWhite));
        if (currentPosition == position)
            viewHolder.categoryContainer.setBackgroundColor(context.getResources().getColor(R.color.colorSelected));
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout categoryContainer;
        TextView textView;
        ImageView imageView;

        public ViewHolder(View v) {
            super(v);
            categoryContainer = (LinearLayout) v.findViewById(R.id.categoryContainer);
            textView = (TextView) v.findViewById(R.id.title);
            imageView = (ImageView) v.findViewById(R.id.image);
        }
    }
}