package com.health.adapter.viewpager;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.health.fragment.CartFragment;
import com.health.fragment.CategoryFragment;
import com.health.fragment.HomeFragment;
import com.health.fragment.ProfileFragment;

public class MainPagerAdapter extends FragmentStatePagerAdapter {
    public MainPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        Fragment fragment;
        Bundle args = new Bundle();
        switch (i)
        {
            case 1:
                fragment = CategoryFragment.newInstance("sdkdkd"+i, "skdkd"+i);
                break;
            case 2:
                fragment = CartFragment.newInstance("sdkdkd"+i, "skdkd"+i);
                break;
            case 4:
                fragment = ProfileFragment.newInstance("sdkdkd"+i, "skdkd"+i);
                break;
            default:
                fragment = HomeFragment.newInstance("sdkdkd"+i, "skdkd"+i);
                break;
        }
        // Our object is just an integer.
//        args.putInt(HomeFragment.ARG_OBJECT, i + 1);
//        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return "OBJECT " + (position + 1);
    }
}
