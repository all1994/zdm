package com.health.adapter.recyclerview;


import android.content.res.ColorStateList;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.interfaces.ServiceClickListener;
import com.health.model.ServiceModel;

import java.util.ArrayList;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ViewHolder> {

    private static final String TAG = "Cus tomAdapter";

    private ArrayList<ServiceModel> models;

    private ServiceClickListener serviceClickListener;

    public ServiceAdapter(ArrayList<ServiceModel> models, ServiceClickListener serviceClickListener) {
        this.models = models;
        this.serviceClickListener = serviceClickListener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView imageView;
        LinearLayout container;

        public ViewHolder(View v) {
            super(v);
            textView = (TextView) v.findViewById(R.id.title);
            imageView = (ImageView) v.findViewById(R.id.image);
            container = (LinearLayout) v.findViewById(R.id.container);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_service, viewGroup, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.textView.setText(models.get(position).getTitle());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            viewHolder.imageView.getBackground().setTint(models.get(position).getColor());
        }
        viewHolder.imageView.setImageResource(models.get(position).getDrawable());
        viewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceClickListener.onServiceClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return models.size();
    }
}