package com.health.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.activity.DiscussionActivity;
import com.health.adapter.recyclerview.ServiceAdapter;
import com.health.interfaces.ServiceClickListener;
import com.health.model.ServiceModel;

import java.util.ArrayList;

public class HomeFragment extends Fragment implements ServiceClickListener {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private RecyclerView serviceList;
    private ServiceAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<ServiceModel> services;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        services = new ArrayList<>();
        for (int i = 0; i < getResources().getStringArray(R.array.service_titles).length; i++) {
            services.add(new ServiceModel( getResources().getStringArray(R.array.service_titles)[i],
                    getResources().getIntArray(R.array.colorServices)[i],
                    getResources().obtainTypedArray(R.array.service_images).getResourceId(i, 0)));
        }
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        serviceList = rootView.findViewById(R.id.serviceList);
        mLayoutManager =  new GridLayoutManager(getActivity(), 5);
        mAdapter = new ServiceAdapter(services, HomeFragment.this);
        serviceList.setLayoutManager(mLayoutManager);
        serviceList.setAdapter(mAdapter);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onServiceClick(int serviceId) {
        switch (serviceId){
            case 2:
                Intent intent = new Intent(getContext(), DiscussionActivity.class);
                startActivity(intent);
            default:
                break;
        }
    }
}
