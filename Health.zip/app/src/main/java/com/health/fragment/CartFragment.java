package com.health.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.adapter.recyclerview.CartAdapter;
import com.health.adapter.recyclerview.ServiceAdapter;
import com.health.model.DrugModel;
import com.health.model.ServiceModel;

import java.util.ArrayList;

public class CartFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private RecyclerView cartList;
    private CartAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<DrugModel> drugModels;

    public CartFragment() {
        // Required empty public constructor
    }

    public static CartFragment newInstance(String param1, String param2) {
        CartFragment fragment = new CartFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        drugModels = new ArrayList<>();
        drugModels.add(new DrugModel(0, "Drug 1", "1293", 1, 1));
        drugModels.add(new DrugModel(1, "Drug 2", "293", 12, 1));
        drugModels.add(new DrugModel(2, "Drug 3", "19", 11, 1));
        View rootView = inflater.inflate(R.layout.fragment_cart, container, false);
        cartList = rootView.findViewById(R.id.cartList);
        mLayoutManager =  new LinearLayoutManager(getActivity());
        mAdapter = new CartAdapter(drugModels, getContext());
        cartList.setLayoutManager(mLayoutManager);
        cartList.setAdapter(mAdapter);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
