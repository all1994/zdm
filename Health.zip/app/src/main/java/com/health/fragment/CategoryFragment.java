package com.health.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.health.R;
import com.health.activity.DrugListActivity;
import com.health.adapter.recyclerview.CategoryAdapter;
import com.health.adapter.recyclerview.SubCategoryAdapter;
import com.health.interfaces.CategoryClickListener;
import com.health.model.CategoryModel;
import com.health.model.ServiceModel;
import com.health.model.SubCategoryModel;
import com.health.util.Constants;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;


public class CategoryFragment extends Fragment implements CategoryClickListener {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    private RecyclerView categoryList, itemList;
    private CategoryAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<CategoryModel> categories;
    private ArrayList<SubCategoryModel> subCategoryModels;
    private SubCategoryAdapter adapter;
    private int currentActiveCategory = -1;

    public CategoryFragment() {
        // Required empty public constructor
    }

    public static CategoryFragment newInstance(String param1, String param2) {
        CategoryFragment fragment = new CategoryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        categories = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(Constants.categoryData);
            for (int i = 0; i < jsonArray.length(); i++) {
                    categories.add(new CategoryModel( jsonArray.getJSONObject(i).getInt("id"),
                        jsonArray.getJSONObject(i).getString("title"),
                        getResources().obtainTypedArray(R.array.service_images).getResourceId(i, 0)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        View rootView = inflater.inflate(R.layout.fragment_category, container, false);
        categoryList = rootView.findViewById(R.id.categoryList);
        itemList = rootView.findViewById(R.id.itemList);
        mLayoutManager =  new LinearLayoutManager(getActivity());
        mAdapter = new CategoryAdapter(categories, getContext(), CategoryFragment.this);
        categoryList.setLayoutManager(mLayoutManager);
        categoryList.setAdapter(mAdapter);

        itemList.setHasFixedSize(true);
        subCategoryModels = new ArrayList<>();
        itemList.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new SubCategoryAdapter(subCategoryModels, getContext());
        itemList.setAdapter(adapter);
        setSubCategoryModels();
        return rootView;
    }

    public void setSubCategoryModels(){
        subCategoryModels.clear();
        try {
            JSONArray jsonArray = new JSONArray(Constants.subCategoryData);
            for (int i = 0; i < jsonArray.length(); i++) {
                if (currentActiveCategory==-1)
                    subCategoryModels.add(new SubCategoryModel(
                            jsonArray.getJSONObject(i).getInt("id"),
                            jsonArray.getJSONObject(i).getString("title"),
                            jsonArray.getJSONObject(i).getString("drawable"),
                            jsonArray.getJSONObject(i).getInt("categoryId"))
                    );
                else
                {
                    if (jsonArray.getJSONObject(i).getInt("categoryId")==currentActiveCategory)
                        subCategoryModels.add(new SubCategoryModel(
                                jsonArray.getJSONObject(i).getInt("id"),
                                jsonArray.getJSONObject(i).getString("title"),
                                jsonArray.getJSONObject(i).getString("drawable"),
                                jsonArray.getJSONObject(i).getInt("categoryId"))
                        );
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }


    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onCategoryClick(int categoryId) {
        if (categoryId == 0)
        {
            Intent intent = new Intent(getContext(), DrugListActivity.class);
            intent.putExtra("drugType", 0);
            getContext().startActivity(intent);
        }
        else {
            currentActiveCategory = categoryId;
            setSubCategoryModels();
        }
    }
}
