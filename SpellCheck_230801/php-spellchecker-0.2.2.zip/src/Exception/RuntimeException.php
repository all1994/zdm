<?php

declare(strict_types=1);

namespace PhpSpellcheck\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
