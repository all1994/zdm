<?php

declare(strict_types=1);

namespace PhpSpellcheck\Exception;

class LogicException extends \LogicException implements ExceptionInterface
{
}
