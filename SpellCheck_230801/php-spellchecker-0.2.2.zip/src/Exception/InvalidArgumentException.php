<?php

declare(strict_types=1);

namespace PhpSpellcheck\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
