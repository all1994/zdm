<?php

declare(strict_types=1);

namespace PhpSpellcheck\Exception;

interface ExceptionInterface
{
}
